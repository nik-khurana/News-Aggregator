package com.nikhil.khurana.hw5;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NewsViewHolder extends RecyclerView.ViewHolder {
    TextView title,date,author,desc,page;
    ImageView imageView;
    public NewsViewHolder(@NonNull View itemView) {
        super(itemView);
        title=itemView.findViewById(R.id.title);
        date=itemView.findViewById(R.id.date);
        author=itemView.findViewById(R.id.author);
        desc=itemView.findViewById(R.id.description);
        imageView=itemView.findViewById(R.id.imageView);
        page=itemView.findViewById(R.id.page);
    }
}
