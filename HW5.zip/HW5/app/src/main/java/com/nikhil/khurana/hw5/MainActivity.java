package com.nikhil.khurana.hw5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private final HashMap<String, ArrayList<MainMenu>> menuData = new HashMap<>();
    final ArrayList<String> temp=new ArrayList<>();
    private Menu show_menu;
    private DrawerLayout drawerLayout;
    private ListView drawerList;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private ArrayAdapter<String> arrayAdapter;
    private ViewPager2 viewPager2;
    NewsAdapter newsAdapter;
    final ArrayList<News> news=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(!doNetCheck()){
            showNoNetworkDialog();
            return;
        }

        MainMenuVolleyLoader.getSourceData(this);
        drawerLayout = findViewById(R.id.drawer_layout);
        drawerList = findViewById(R.id.drawer_list);
        actionBarDrawerToggle = new ActionBarDrawerToggle(MainActivity.this,drawerLayout,R.string.open,R.string.close);
        viewPager2 = findViewById(R.id.viewpager);

        drawerList.setOnItemClickListener((adapterView, view, i, l) -> {
            ConnectivityManager cm1=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork1 = cm1.getActiveNetworkInfo();
            boolean isConnected1 = activeNetwork1 != null && activeNetwork1.isConnectedOrConnecting();
                if(isConnected1){

                    setTitle(temp.get(i));
                    ArrayList<MainMenu> arrayList=menuData.get("all");
                    for(int j = 0; j< Objects.requireNonNull(arrayList).size(); j++){
                        if(temp.get(i).equalsIgnoreCase(arrayList.get(j).getName())){
                            drawerLayout.closeDrawer(drawerList);
                            SpecificVolleyLoader.getSourceData(MainActivity.this,arrayList.get(j).getId());
                            newsAdapter = new NewsAdapter(MainActivity.this,news);
                            viewPager2.setAdapter(newsAdapter);
                            viewPager2.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);

                    }
                }
            }else{
                    showNoNetworkDialog();
                }
        });





    }
    @SuppressLint("NewApi")
    private boolean doNetCheck() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

        return isConnected;
    }

   protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        if(doNetCheck())
            actionBarDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if(doNetCheck())
            actionBarDrawerToggle.onConfigurationChanged(newConfig);
    }

    public void update(ArrayList<MainMenu> listIn){
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }
        for(MainMenu m:listIn) {
            if (!menuData.containsKey(m.getCategory())) {
                String s=m.getCategory();
                menuData.put(s, new ArrayList<>());
            }
            ArrayList<MainMenu> mlist = menuData.get(m.getCategory());
            assert mlist != null;
            mlist.add(m);
        }

        menuData.put("all",listIn);
        ArrayList<String> templist=new ArrayList<>(menuData.keySet());
        Collections.sort(templist);
        for(String s:templist){
            show_menu.add(s);
        }
        temp.clear();
        for(int i=0;i<listIn.size();i++){
            temp.add(listIn.get(i).getName());
        }
        arrayAdapter=new ArrayAdapter<>(MainActivity.this,R.layout.drawer_item,temp);
        drawerList.setAdapter(arrayAdapter);
        setTitle(getTitle()+" ("+temp.size()+") ");


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.show_menu = menu;
        return true;
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        temp.clear();
        ArrayList<MainMenu>tempe;
        if(menuData.containsKey(item.getTitle().toString())){
            tempe=menuData.get(item.getTitle().toString());
            for(int j = 0; j< Objects.requireNonNull(tempe).size(); j++){
                temp.add(tempe.get(j).getName());
            }
        }
        setTitle(item.getTitle().toString()+ " ("+temp.size()+") ");
        arrayAdapter.notifyDataSetChanged();
        return super.onOptionsItemSelected(item);

    }
    public void showNoNetworkDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("No Internet Connection");
        builder.setMessage("Connect To Internet and Try Again");
        builder.create().show();
    }


    public void updatePages(ArrayList<News> newsArrayList) {
        news.clear();
        news.addAll(newsArrayList);
        newsAdapter.notifyItemRangeChanged(0,news.size());




    }
}