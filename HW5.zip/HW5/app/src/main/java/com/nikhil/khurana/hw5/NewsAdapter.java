package com.nikhil.khurana.hw5;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<NewsViewHolder> {
    ArrayList<News> newsArrayList;
    MainActivity mainActivity;
    public NewsAdapter(MainActivity mainActivity,ArrayList<News> news) {
        this.mainActivity=mainActivity;
        newsArrayList=news;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NewsViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.news_entry,parent,false));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        News news=newsArrayList.get(position);
        holder.title.setText(news.getTitle());
        if(news.getTitle().length()>0){
            holder.title.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(news.getUrl()));
                    view.getContext().startActivity(intent);
                }
            });
        }
        holder.author.setText(news.getAuthor());
        holder.desc.setText(news.getDescription());
        holder.desc.setMovementMethod(new ScrollingMovementMethod());
        if(news.getDescription().length()>0){
            holder.desc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(news.getUrl()));
                    view.getContext().startActivity(intent);
                }
            });
        }
        holder.date.setText(news.getTime());

        holder.page.setText("Story "+(position+1)+" of "+newsArrayList.size());

        if(news.getImage().length()>0) {
            Picasso picasso = null;
            picasso = Picasso.get();
            picasso.setLoggingEnabled(false);
            picasso.load(news.getImage())
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.loading)
                    .memoryPolicy(MemoryPolicy.NO_CACHE)
                    .into(holder.imageView);

        }else{
            holder.imageView.setImageResource(R.drawable.noimage);
        }
        if(news.getImage().length()>0){
            holder.imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(news.getUrl()));
                    view.getContext().startActivity(intent);
                }
            });
        }



    }

    @Override
    public int getItemCount() {
        return newsArrayList.size();
    }
}
