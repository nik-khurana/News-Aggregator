package com.nikhil.khurana.hw5;

import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SpecificVolleyLoader {
    private static String url="https://newsapi.org/v2/top-headlines?apiKey=25f6df1694a44343a002f9f1e269a408&sources=";

    public static void getSourceData(MainActivity mainActivity, String id) {
        RequestQueue queue = Volley.newRequestQueue(mainActivity);;

        Uri.Builder buildURL = Uri.parse(url+id).buildUpon();
        String urlToUse = buildURL.build().toString();
        Response.Listener<JSONObject> listener = response -> handleresults(mainActivity, response.toString());

        Response.ErrorListener error = error1 -> handleresults(mainActivity,error1.toString());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urlToUse, null, listener, error){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("User-Agent", "");
                return headers;
            }
        };
        queue.add(jsonObjectRequest);
    }

    private static void handleresults(MainActivity mainActivity, String toString) {
        if(toString!=null){
            ArrayList<News> news=parseJSON(toString);
            mainActivity.updatePages(news);
        }
    }

    private static ArrayList<News> parseJSON(String toString) {
     try{
         ArrayList<News> arrayList=new ArrayList<>();
         JSONObject object=new JSONObject(toString);
        int count=object.getInt("totalResults");
        if(count>11){
            count=10;
        }
        JSONArray array=object.getJSONArray("articles");
        for(int i=0;i<count;i++){
            JSONObject object1=array.getJSONObject(i);
            String title=object1.getString("title");
            String date=object1.getString("publishedAt");
            String author=object1.getString("author");
            String description=object1.getString("description");
            String image=object1.getString("urlToImage");
            String url=object1.getString("url");
            arrayList.add(new News(author,title,description,url,image,date));
        }
        return arrayList;

     }catch (Exception e){
         e.printStackTrace();
     }
     return null;
    }
}
