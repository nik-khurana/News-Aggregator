package com.nikhil.khurana.hw5;

import java.io.Serializable;

public class News implements Serializable{
    String author,title,description,url,image,time;

    public News(String author, String title, String description, String url, String image, String time) {
        this.author = author;
        this.title = title;
        this.description = description;
        this.url = url;
        this.image = image;
        this.time = time;
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getUrl() {
        return url;
    }

    public String getImage() {
        return image;
    }

    public String getTime() {
        return time;
    }
}
