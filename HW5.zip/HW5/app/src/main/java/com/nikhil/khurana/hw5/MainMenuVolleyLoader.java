package com.nikhil.khurana.hw5;

import android.net.Uri;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainMenuVolleyLoader {
    static String url="https://newsapi.org/v2/sources?apiKey=25f6df1694a44343a002f9f1e269a408";

    public static void getSourceData(MainActivity mainActivity) {
        RequestQueue queue = Volley.newRequestQueue(mainActivity);
        Uri.Builder buildURL = Uri.parse(url).buildUpon();
        String urlToUse = buildURL.build().toString();
        Response.Listener<JSONObject> listener = response -> handleresults(mainActivity,response.toString());
        Response.ErrorListener error = error1 -> handleresults(mainActivity,error1.toString());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urlToUse, null, listener, error){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("User-Agent", "");
                return headers;
            }
        };
        queue.add(jsonObjectRequest);
    }

    private static void handleresults(MainActivity mainActivity, String toString) {
        ArrayList<MainMenu> menu=parseJson(toString);
        if(toString!=null){
            mainActivity.update(menu);
        }
    }

    private static ArrayList<MainMenu> parseJson(String toString) {
        ArrayList<MainMenu> list = new ArrayList<>();
        try {
            JSONObject object1 = new JSONObject(toString);
            JSONArray array1 = object1.getJSONArray("sources");
            for (int i = 0; i < array1.length(); i++) {
                JSONObject object2 = array1.getJSONObject(i);
                String id = object2.getString("id");
                String name = object2.getString("name");
                String category = object2.getString("category");
                list.add(new MainMenu(id, name, category));
            }
           // Collections.sort(list);
            return list;

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
